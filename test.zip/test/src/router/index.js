import { createRouter, createWebHistory } from 'vue-router';
import Home from '../views/Home.vue';
import Login from '../components/Auth/Login.vue';
import Register from '../components/Auth/Register.vue';
import TaskDetail from '../components/Task/TaskDetail.vue';
import TaskForm from '../components/Task/TaskForm.vue';
import TaskList from '../components/Task/TaskList.vue';

const routes = [
  {
    path: '/',
    redirect: '/login' // 默认重定向到登录页
  },
  {
    path: '/login',
    name: 'Login',
    component: Login
  },
  {
    path: '/register',
    name: 'Register',
    component: Register
  },
  {
    path: '/home',
    name: 'Home',
    component: Home,
    children: [
      {
        path: '', // 默认子路由，显示TaskDetail
        name: 'TaskDetail',
        component: TaskDetail
      },
      {
        path: 'add',
        name: 'TaskForm',
        component: TaskForm
      },
      {
        path: 'list',
        name: 'TaskList',
        component: TaskList
      }
    ]
  }
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;